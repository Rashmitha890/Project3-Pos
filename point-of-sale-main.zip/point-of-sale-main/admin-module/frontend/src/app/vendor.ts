export class Vendor {
id:number | any;
  name: string | any;
  email: string | any;
  phoneNumber: string | any;

  company: string | any;
  active: boolean | any;
}
