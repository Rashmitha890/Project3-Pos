export class Employee {
    id?:number;
      name?: string;
      email?: string;
      phoneNumber?: string;
      address?: string;
      password?: string;
      role?: string;
      active?: boolean;
    }
    