export class Address {
    public addressLine?:string;
    public city?:string;
    public pinCode?:number;
}

