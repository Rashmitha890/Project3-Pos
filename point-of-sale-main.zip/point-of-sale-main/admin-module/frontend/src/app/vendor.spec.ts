import { Vendor } from './vendor';

describe('Vendor', () => {
  it('should create an instance', () => {
    expect(new Vendor()).toBeTruthy();
  });
});
