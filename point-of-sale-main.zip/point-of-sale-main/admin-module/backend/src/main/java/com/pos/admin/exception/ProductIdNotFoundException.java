package com.pos.admin.exception;

public class ProductIdNotFoundException extends RuntimeException {

	public ProductIdNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
