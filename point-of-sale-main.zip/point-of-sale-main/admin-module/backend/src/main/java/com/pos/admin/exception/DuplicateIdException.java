package com.pos.admin.exception;

public class DuplicateIdException extends RuntimeException{
	public DuplicateIdException(String msg) {
		super(msg);
	}
}
