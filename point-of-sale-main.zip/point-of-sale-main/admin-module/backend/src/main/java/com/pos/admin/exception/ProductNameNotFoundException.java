package com.pos.admin.exception;

public class ProductNameNotFoundException extends RuntimeException{	
	public ProductNameNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	

}
