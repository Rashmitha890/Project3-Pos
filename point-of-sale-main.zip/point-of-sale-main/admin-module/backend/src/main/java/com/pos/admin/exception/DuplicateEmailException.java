package com.pos.admin.exception;

public class DuplicateEmailException extends RuntimeException{

	public DuplicateEmailException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
