package com.pos.admin.exception;

public class EmailNotFoundException extends RuntimeException{

	public EmailNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}

}
